export interface EventInterface {
    setEvent(): void;
    dispatch(event?: any, show?: boolean): void;
}