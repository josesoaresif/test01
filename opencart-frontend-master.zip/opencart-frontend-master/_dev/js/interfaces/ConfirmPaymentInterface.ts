export interface ConfirmPaymentInterface {
    redirect: Location;
    error: string;
}