export interface SucessInterface {
    'success': string | null,
    'validationError'?: string
}