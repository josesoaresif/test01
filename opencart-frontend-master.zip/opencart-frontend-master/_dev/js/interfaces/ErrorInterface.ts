export interface ErrorInterface {
    'error': string
}