export interface FacadeInterface {
    start(): void;
}