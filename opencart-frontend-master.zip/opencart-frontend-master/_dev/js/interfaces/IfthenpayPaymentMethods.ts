export enum IfthenpayPaymentMethod {
    MULTIBANCO = 'multibanco',
    MBWAY = 'mbway',
    PAYSHOP = 'payshop',
    CCARD = 'ccard',
  }