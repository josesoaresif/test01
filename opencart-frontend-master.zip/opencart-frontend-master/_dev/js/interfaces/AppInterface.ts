export interface AppInterface {
    init(): void;
}