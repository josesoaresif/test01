export interface FacadeInterface {
    'orderStatus': 'pending' | 'paid'
}