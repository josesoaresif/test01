<?php
// Heading
$_['heading_title']      = 'Multibanco';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Multibanco payment module!';
$_['text_multibanco']	      = '<a onclick="window.open(\'http://www.ifthensoftware.com/ProdutoX.aspx?ProdID=5\');"><img src="view/image/payment/multibanco.png" alt="multibanco" title="multibanco" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_entidade']        = 'Entity';
$_['entry_subentidade']        = 'Sub-Entity';
$_['entry_valorminimo']        = 'Minimum Value';
$_['entry_order_status'] = 'Order Status:';
$_['entry_order_status_complete'] = 'Order Status Paid:';
$_['entry_geo_zone']     = 'Geo Zone:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';
$_['entry_cb']   = 'Callback:';
$_['entry_ap']   = 'Anti-Phishing Key:';
$_['entry_url']   = 'Url Callback:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Cash On Delivery!';
?>
