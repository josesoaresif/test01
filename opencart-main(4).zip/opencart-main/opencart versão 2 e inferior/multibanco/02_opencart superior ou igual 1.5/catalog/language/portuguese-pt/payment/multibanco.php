<?php
// Text
$_['text_title'] = 'Pagamento por Multibanco';
?>