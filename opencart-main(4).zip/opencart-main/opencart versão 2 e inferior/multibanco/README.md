Ifthenpay module for OpenCart
==============
![Multibanco](https://raw.githubusercontent.com/ifthenpay/omnipay-ifthenpay/master/mb.png)

**This is the Ifthenpay module for OpenCart CMS**

Multibanco is one Portuguese payment method that allows the customer to pay by bank reference.
This plugin will allow you to generate a payment Reference that the customer can then use to pay for his order on the ATM or Home Banking service. This plugin uses one of the several gateways/services available in Portugal, IfthenPay, and a contract with this company is required. See more at [Ifthenpay](https://ifthenpay.com).

# Instructions

Instructions are available inside each folder regarding each version of OpenCart.