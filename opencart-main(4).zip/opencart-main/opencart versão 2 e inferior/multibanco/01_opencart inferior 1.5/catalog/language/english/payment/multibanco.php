<?php
// Text
$_['text_title'] = 'Multibanco';
$_['text_ent'] = 'Entity:';
$_['text_ref'] = 'Reference:';
$_['text_val'] = 'Value:';
?>