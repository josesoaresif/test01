# mbway-opencart
MBWAY Module to Opencart platform

This is the Ifthenpay mbway module for OpenCart CMS

MBWAY is the first inter-bank solution that enables purchases and immediate transfers via smartphones and tablets.

This plugin will allow you to generate a request payment to the customer mobile phone, and he can authorize the payment  for his order on the MBWAY App service. This plugin uses one of the several gateways/services available in Portugal, IfthenPay, and a contract with us is required. See more at Ifthenpay.com.

Instructions:
Instructions are available inside each folder regarding each version of OpenCart.
