<?php
// Text
$_['text_title_payshop'] = 'Payshop';
$_['paymentReturnTitle'] = 'Utilize os dados abaixo para efetuar o pagamento da sua encomenda.';
$_['paymentReturnErrorTitle'] = 'Alguma coisa correu mal!';
$_['paymentReturnErrorText'] = 'Ocorreu um erro ao processar o seu pedido, por favor, entre em contato com a nossa equipe de suporte ao cliente.';
$_['ifthenpayPaymentPanelTitle'] = 'Pagamento por Payshop';
$_['ifthenpayPaymentPanelReferencia'] = 'Referência:';
$_['ifthenpayPaymentPanelValidade'] = 'Validade:';
$_['ifthenpayPaymentPanelTotalToPay'] = 'Valor:';
$_['payshopAlias'] = 'Payshop';
$_['ifthenpayPaymentPanelIdPedido'] = 'IdRequest';
$_['paymentConfirmedSuccess'] = 'Pagamento feito com sucesso.';
?>